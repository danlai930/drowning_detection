# drowning detection  > 2023-12-02 12:14pm
https://universe.roboflow.com/zidan-nlsjs/drowning-detection-e6kbk

Provided by a Roboflow user
License: CC BY 4.0

